import './index.scss'

export default function Cabdois(){

    return(
        <div className='cabedois-comp'>
             
            
        </div>

    )


}