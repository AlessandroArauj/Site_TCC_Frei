import './index.scss'


export default function Cadastrar(){

    return(
        <div className='Carrinho-page'>

        </div>
    )
}