import './index.js'
import Cabecalho from '../../../components/cabecalho/index.js'
import CompProduto from '../../../components/CompPageProduto/index.js'

export default function PageProduto(){

    return(
        <div className='PageProduto'>
            <Cabecalho />
            <CompProduto />

            
            
            
        </div>
    )

    
}