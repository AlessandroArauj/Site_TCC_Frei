import './index.scss'
import AbaUsuario from '../../../components/usuarioinfo'



export default function UsarioPerfil(){

return(
    
    <div className='pagina-perfil-usuario'>
        <AbaUsuario className='abazinha'></AbaUsuario>


        
        
        



    </div>
    
    )

}