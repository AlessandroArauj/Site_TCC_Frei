import Cabdois from '../../../components/cabdois'
import './index.scss'

export default function AddCartao(){

    return(
        <div className='page-add-cartao'>
            <Cabdois />



        </div>


    )


}